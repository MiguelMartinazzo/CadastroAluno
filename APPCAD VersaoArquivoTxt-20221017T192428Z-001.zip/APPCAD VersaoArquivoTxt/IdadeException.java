
/**
 * Escreva uma descrição da classe IdadeValida aqui.
 * 
 * @author (seu nome) 
 * @version (um número da versão ou uma data)
 */
public class IdadeException extends Exception{

    IdadeException(){
        super("Idade invalida.Digite uma idade entre 16 e 100.");
    }
    
    IdadeException(String msg){
        super(msg);
    }
}