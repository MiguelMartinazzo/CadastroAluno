
/**
 * Escreva uma descrição da classe IdadeValida aqui.
 * 
 * @author (seu nome) 
 * @version (um número da versão ou uma data)
 */
public class NotaException extends Exception{
    
    NotaException(){
        super("Nota invalida.Digite uma nota de 0 a 10.");
    }
    
    NotaException(String msg){
        super(msg);
    }
}